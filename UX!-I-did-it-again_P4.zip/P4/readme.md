# DIU - Practica 4, entregables



Revisar [Asignacion_ABtesting](https://github.com/mgea/DIU/blob/master/P4/Asignacion_ABtesting.pdf)
Lista de grupos 

* Users 

Elección y características

* A/B Testing. 


* Tareas realizadas 


* Usability Report de Caso B
* Template de usability.gob (https://www.usability.gov/how-to-and-tools/resources/templates/report-template-usability-test.html) 

* Conclusiones
